
import numpy as np
from pydub import AudioSegment
import io
import whisper

model = whisper.load_model("tiny")

def mp3_to_pcm(mp3_bytes: bytes, target_sr: int = 16000):
    audio = AudioSegment.from_mp3(io.BytesIO(mp3_bytes))

    # Convert to mono and resample to target_sr (16kHz)
    audio = audio.set_channels(1).set_frame_rate(target_sr)

    # Export audio to raw PCM bytes
    pcm_bytes = audio.raw_data
    return np.frombuffer(pcm_bytes, dtype=np.int16).astype(np.float32) / 32768.0  # Normalize

def transcribe_mp3(mp3_bytes: bytes):
    audio = mp3_to_pcm(mp3_bytes)
    result = model.transcribe(audio, language="en")
    return result["text"]