# from fastapi import FastAPI, File, UploadFile, HTTPException
# from fastapi.responses import JSONResponse
# import uvicorn
# from transcribe import transcribe_mp3
# from fastapi.middleware.cors import CORSMiddleware
# app = FastAPI()
#
# app.add_middleware(
#     CORSMiddleware,
#     allow_origins=["*"],  # Allows all origins (can be changed to specific domains in production)
#     allow_credentials=True,
#     allow_methods=["*"],  # Allows all methods (GET, POST, etc.)
#     allow_headers=["*"],  # Allows all headers
# )
# @app.get("/ping")
# async def ping():
#     return {"status": "ok"}
#
# @app.post("/invocations")
# async def invocations(audio: UploadFile = File(...)):
#     try:
#         mp3_bytes = await audio.read()
#         text = transcribe_mp3(mp3_bytes)
#         return JSONResponse({"transcription": text})
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))
#
# if __name__ == '__main__':
#     uvicorn.run(app,port=8080,host='0.0.0.0')

# did changes for sagemaker

import os
import json
import base64
from transcribe import transcribe_mp3

# Load the Whisper model
def model_fn(model_dir):
    import whisper
    # You can set the model size via an environment variable
    model_size = os.environ.get("WHISPER_MODEL_SIZE", "tiny")  # Default to "tiny"
    model = whisper.load_model(model_size)
    return model

# Convert request body into input data (base64 audio)
def input_fn(request_body, content_type):
    if content_type == 'application/json':
        body = json.loads(request_body)
        audio_b64 = body['audio']  # Assuming the audio comes as base64 encoded
        audio_bytes = base64.b64decode(audio_b64)
        return audio_bytes
    else:
        raise ValueError(f"Unsupported content type: {content_type}")

# Perform the transcription
def predict_fn(input_data, model):
    return transcribe_mp3(input_data)

# Format the output (return the transcription as a string)
def output_fn(prediction, accept):
    return {"transcription": prediction}
