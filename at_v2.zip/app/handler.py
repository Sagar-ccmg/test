from flask import Flask, request, jsonify
from inference import load_model, transcribe_audio

app = Flask(__name__)
model = load_model()

@app.route("/ping", methods=["GET"])
def ping():
    return "Healthy", 200

@app.route("/invocations", methods=["POST"])
def invoke():
    audio = request.files.get("audio")
    if audio is None:
        return jsonify({"error": "No audio uploaded"}), 400

    transcription = transcribe_audio(model, audio)
    return jsonify({"transcription": transcription})
