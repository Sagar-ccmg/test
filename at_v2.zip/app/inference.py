from faster_whisper import WhisperModel

def load_model():
    model = WhisperModel("base", compute_type="int8")  # Adjust as needed
    return model

def transcribe_audio(model, audio_file):
    segments, _ = model.transcribe(audio_file)
    return " ".join([seg.text for seg in segments])
